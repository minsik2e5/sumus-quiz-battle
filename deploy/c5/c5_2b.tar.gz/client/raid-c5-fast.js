/* V0.9.3C.5 FAST DEPLOY — classroom learning ledger, partial end, results, recovery guard. */
(() => {
  const isRaid = () => typeof V093_isRaid === 'function' && V093_isRaid();
  const ensureLearning = player => player.raidLearning ||= { schemaVersion:1, counts:{correct:0,wrong:0,pass:0,timeout:0}, words:{} };
  const learningRow = (player, question) => {
    const learning = ensureLearning(player);
    const id = String(question?.id || '');
    return learning.words[id] ||= {
      id, word:String(question?.word?.word || ''), meaning:String(question?.word?.rawMeaning || ''), expected:String(question?.answer || ''),
      correct:0, wrong:0, pass:0, timeout:0
    };
  };
  const record = (player, question, outcome) => {
    if (!player || !question) return;
    const key = outcome === 'timeout' ? 'timeout' : outcome;
    if (!['correct','wrong','pass','timeout'].includes(key)) return;
    const row = learningRow(player, question), learning = ensureLearning(player);
    row[key] += 1; learning.counts[key] += 1; row.lastOutcome = key; row.updatedAt = Date.now();
  };
  const currentQuestion = player => player?.raidReviveQuestions?.[0] || player?.questions?.[player?.questionIndex];

  const baseSetup = RaceEngine.setup.bind(RaceEngine);
  RaceEngine.setup = function(){
    const result = baseSetup();
    if (isRaid()) state.players.forEach(player => {
      player.raidSessionEnded = false; player.raidManualEnd = false;
      player.raidLearning = { schemaVersion:1, counts:{correct:0,wrong:0,pass:0,timeout:0}, words:{} };
    });
    return result;
  };

  const baseAnswer = TeacherBridge.answer.bind(TeacherBridge);
  TeacherBridge.answer = function(payload){
    if (!isRaid()) return baseAnswer(payload);
    const player = state.players.find(p => p.id === payload?.playerId);
    const question = currentQuestion(player);
    if (!player || !question || question.id !== payload?.questionId || player.finished || state.race.paused) return baseAnswer(payload);
    let outcome;
    if (payload.action === 'timeout') outcome = 'timeout';
    else if (payload.action === 'pass') outcome = 'pass';
    else outcome = QuizEngine.judge(question, payload.answer) ? 'correct' : 'wrong';
    record(player, question, outcome);
    return baseAnswer(payload);
  };

  const resultPlayer = player => ({
    id:player.id,name:player.name,character:player.character,ready:!!player.ready,connected:player.connected!==false,
    rangeFrom:player.rangeFrom,rangeTo:player.rangeTo,units:player.units||[],assignedTotal:player.assignedTotal||0,questionIndex:player.questionIndex||0,
    combo:player.combo||0,correct:player.correct||0,wrong:player.wrong||0,pass:player.pass||0,maxCombo:player.maxCombo||0,times:player.times||[],finished:!!player.finished,
    raid:player.raid?RaidFoundation.snapshot(player.raid):null,raidSessionEnded:!!player.raidSessionEnded,raidManualEnd:!!player.raidManualEnd,
    raidResult:RaidResultsModel.publicResult(player)
  });

  const baseSendOfficial = TeacherBridge.sendOfficialResults.bind(TeacherBridge);
  TeacherBridge.sendOfficialResults = function(){
    if (!isRaid()) return baseSendOfficial();
    state.players.forEach((player,index)=>{
      LocalTransport.send('GAME_FINISH',{...EventPayload.base(player.id),targetClientId:player.clientId||'',rank:index+1,player:resultPlayer(player),award:[]});
    });
  };

  const baseFinish = RaceEngine.finish.bind(RaceEngine);
  RaceEngine.finish = function(){
    if (isRaid()) state.players.forEach(player => {
      player.raidSessionEnded = true;
      player.raidManualEnd = !player.finished;
    });
    return baseFinish();
  };

  const baseAcceptSnapshot = StudentApp.acceptSnapshot.bind(StudentApp);
  StudentApp.acceptSnapshot = function(snapshot){
    const result = baseAcceptSnapshot(snapshot);
    if (snapshot?.arena === 'raid') {
      const p = snapshot.players?.find(x => x.id === StudentSession.playerId);
      if (p) {
        StudentSession.player = p;
        if ((p.finished || p.raidSessionEnded) && p.raidResult) {
          StudentSession.screen = 'official';
          StudentSession.official = { player:p, rank:StudentSession.rank || 1 };
          this.render();
        } else if (p.currentQuestion && p.raidAttemptId && p.raid?.attackDeadline) {
          StudentSession.raidTiming = {questionStartAt:p.raid.attackStartAt,attackDeadline:p.raid.attackDeadline,durationMs:p.raid.attackDurationMs};
        }
      }
    }
    return result;
  };

  const baseStudentRender = StudentApp.render.bind(StudentApp);
  StudentApp.render = function(){
    const raid = StudentSession.snapshot?.arena === 'raid' || StudentSession.player?.raid || RoleParams.get('mode') === 'raid';
    if (raid && (StudentSession.screen === 'finish' || StudentSession.screen === 'official') && window.SUMUS_RAID_RESULTS) {
      document.body.classList.add('raid-mode','role-student');
      const root = document.getElementById('studentRoot');
      if (root) {
        root.innerHTML = `<div class="student-app"><div class="student-shell raid-c5-result-shell"><main class="student-view">${window.SUMUS_RAID_RESULTS.renderStudent(StudentSession.player || StudentSession.official?.player || {})}</main></div></div>`;
        return;
      }
    }
    return baseStudentRender();
  };

  document.addEventListener('click',event=>{
    const button = event.target.closest?.('#studentReturnLobby');
    if (!button) return;
    StudentSession.feedback = null; StudentSession.question = null; StudentSession.attemptId = ''; StudentSession.official = null;
    StudentSession.screen = StudentSession.battleCode ? 'waiting' : 'enter';
    StudentApp.render();
  },true);

  // Teacher recovery race: a snapshot saved before a newer teacher click must not rewind the UI.
  let lastTeacherInteractionAt = 0;
  document.addEventListener('pointerdown',event=>{
    if (AppRole !== 'teacher') return;
    if (event.target.closest?.('#setup,#lobby,#race,#results,[data-arena],[data-raid-result],button,input,select')) lastTeacherInteractionAt = Date.now();
  },true);
  const previousTeacherHandle = TeacherBridge.handle;
  TeacherBridge.handle = function(message){
    if (message?.type === 'SERVER_ROOM_STATE' && isRaid()) {
      const saved = message.payload?.state || message.payload?.snapshot;
      const savedAt = Number(saved?.savedAt || 0);
      if (saved && lastTeacherInteractionAt && ((savedAt && savedAt <= lastTeacherInteractionAt) || (!savedAt && Date.now()-lastTeacherInteractionAt <= 1400))) return;
    }
    return previousTeacherHandle.call(this,message);
  };

  const style = document.createElement('style');
  style.dataset.sumusRaidC5='fast-deploy';
  style.textContent = `
    #results.raid-results-active>*:not(#raidResultsRoot){display:none!important}#results.raid-results-active{padding:0!important;background:#020914!important;overflow:auto!important}
    .raid-teacher-results{min-height:100vh;padding:20px;color:#f7f8fb;background:radial-gradient(circle at 75% 10%,#4e1a7438,transparent 32%),linear-gradient(145deg,#041325,#020813);font-family:Inter,Pretendard,sans-serif}
    .raid-teacher-results>header{display:flex;justify-content:space-between;align-items:center;gap:16px}.raid-teacher-results h1,.raid-student-result h1{margin:4px 0;color:#ffe694;font-family:Georgia,serif}.raid-result-actions{display:flex;gap:8px}.raid-result-actions button,.raid-entry-primary{border:1px solid #d8ae5a;background:#0b2646;color:#fff4b5;padding:11px 16px;font-weight:900;border-radius:9px}.raid-result-actions .primary,.raid-entry-primary{background:linear-gradient(135deg,#1a66bc,#3b2b8b)}
    .raid-class-summary,.raid-result-metrics,.raid-detail-metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin:18px 0}.raid-class-summary article,.raid-result-metrics article,.raid-detail-metrics article{padding:12px;border:1px solid #31526e;background:#07172a;border-radius:10px}.raid-class-summary small,.raid-result-metrics small,.raid-detail-metrics small{display:block;color:#83b9d4;font-size:9px}.raid-class-summary b,.raid-result-metrics b,.raid-detail-metrics b{display:block;margin-top:5px;font-size:20px}
    .raid-teacher-results main{display:grid;grid-template-columns:minmax(0,1.5fr) minmax(300px,.7fr);gap:12px}.raid-result-roster,.raid-result-detail,.raid-class-review{border:1px solid #294f70;background:#061426;border-radius:12px;padding:10px}.raid-result-table-head,.raid-result-roster>button{display:grid;grid-template-columns:1.2fr .8fr .8fr .8fr .7fr .6fr;gap:6px;align-items:center}.raid-result-table-head{padding:9px;color:#7ea8c0;font-size:9px}.raid-result-roster>button{width:100%;padding:10px;border:0;border-top:1px solid #16334d;background:transparent;color:#fff;text-align:left}.raid-result-roster>button.active{background:#12345c}.raid-result-roster .clear{color:#61e6a1}.raid-result-roster .partial{color:#ffd56a}.raid-result-roster .incomplete{color:#ff8f8f}
    .raid-retry-list{display:grid;gap:7px}.raid-retry-list article{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:4px;padding:9px;border:1px solid #254963;background:#07182a;border-radius:9px}.raid-retry-list article div span{display:block;color:#9bb5c7;font-size:10px}.raid-retry-list strong{color:#ffba67;font-size:10px}.raid-retry-list small{grid-column:1/-1;color:#6f96b1}.raid-class-review-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px}.raid-class-review-grid article{padding:10px;background:#07182a;border:1px solid #254963;border-radius:9px}.raid-class-review-grid span,.raid-class-review-grid strong{display:block;margin-top:4px;color:#9bb5c7;font-size:10px}
    .raid-c5-result-shell{width:min(100%,520px)!important}.raid-student-result{padding:8px 2px 24px;color:#f7f8fb}.raid-student-result header{text-align:center;padding:12px 0}.raid-student-result header small{color:#55d9ff;letter-spacing:.14em;font-weight:900}.raid-student-result h1{font-size:32px}.raid-student-result p{color:#9cb3c3}.raid-result-metrics{grid-template-columns:repeat(2,minmax(0,1fr))}.raid-student-review{margin-top:14px}.raid-student-review h2{margin:3px 0 10px}.raid-entry-primary{width:100%;margin-top:16px}
    @media(max-width:760px){.raid-teacher-results main{grid-template-columns:1fr}.raid-class-summary{grid-template-columns:repeat(2,1fr)}.raid-class-review-grid{grid-template-columns:1fr}.raid-teacher-results>header{align-items:flex-start;flex-direction:column}}
  `;
  document.head.appendChild(style);
  window.SUMUS_RAID_C5_FAST = Object.freeze({build:'V0.9.3C.5-fast-deploy',record});
})();
