    /* V0.9.3C.1 PREMIUM RAID ASSETS — local-only, replaceable, gameplay-neutral; original SVG/CSS fallback preserved. */
/* compatibility ids: raid-arena-common raid-arena-elite raid-arena-boss */
    const RaidAssetDirector = (() => {
      ['characters','monsters','arenas','fx','ui'].forEach(group => { if (!AssetRegistry.groups[group]) AssetRegistry.groups[group] = new Map(); });
      const rows = [];
      const add = (group,id,url,label,fallback='svg-css') => { rows.push([group,id,url,label]); AssetRegistry.register(group,id,{kind:'replaceable-image',url,label,fallback}); };

      const playerStates = ['idle','attack','critical','hit','shield','down','revive','special'];
      playerStates.forEach(state => add('characters',`raid-player-main-${state}`,`/assets/raid/player/raid-player-main-${state}.png`,`SUMUS star guardian ${state}`));
      add('characters','raid-player-default','/assets/raid/player/raid-player-main-idle.png','SUMUS star guardian');

      ['idle','attack','hit','clear'].forEach(state => add('monsters',`raid-common-${state}`,`/assets/raid/common/raid-common-${state}.png`,`Common spirit ${state}`));
      ['idle','attack','hit','guard','clear'].forEach(state => add('monsters',`raid-elite-${state}`,`/assets/raid/elite/raid-elite-${state}.png`,`Elite guardian ${state}`));
      ['idle','attack','hit','guard','heavy-charge','clear'].forEach(state => add('monsters',`raid-boss-${state}`,`/assets/raid/boss/raid-boss-${state}.png`,`Boss ${state}`));

      // Compatibility aliases retained for the frozen RAID presentation/tests.
      add('monsters','raid-common-spirit','/assets/raid/common/raid-common-idle.png','Mintling word spirit');
      add('monsters','raid-elite-guardian','/assets/raid/elite/raid-elite-idle.png','Memory guardian');
      add('monsters','raid-boss-forgotten-queen','/assets/raid/boss/raid-boss-idle.png','Forgotten queen');

      const fxFiles = {
        'raid-fx-hit':'raid-fx-hit-normal','raid-fx-critical':'raid-fx-hit-critical','raid-fx-hit-normal':'raid-fx-hit-normal','raid-fx-hit-weak':'raid-fx-hit-weak','raid-fx-hit-critical':'raid-fx-hit-critical',
        'raid-fx-shield':'raid-fx-shield','raid-fx-guard':'raid-fx-guard','raid-fx-guard-break':'raid-fx-guard-break','raid-fx-perfect-break':'raid-fx-perfect-break',
        'raid-fx-heavy':'raid-fx-heavy-hit','raid-fx-heavy-hit':'raid-fx-heavy-hit','raid-fx-heavy-charge':'raid-fx-heavy-charge','raid-fx-heavy-cancel':'raid-fx-heavy-cancel','raid-fx-player-hit':'raid-fx-player-hit'
      };
      Object.entries(fxFiles).forEach(([id,file]) => add('fx',id,`/assets/raid/fx/${file}.png`,id));
      // Pending final art keeps local fallback while preserving API surface.
      add('fx','raid-fx-revive','/assets/raid/fx/raid-fx-revive.png','Revive effect');
      add('fx','raid-fx-clear','/assets/raid/fx/raid-fx-word-tamed.png','Word tamed effect');

      ['common','elite','boss'].forEach(tier => add('arenas',`raid-arena-${tier}`,`/assets/raid/arenas/${tier}.webp`,`${tier} arena`));
      add('ui','raid-ui-broadcast','/assets/raid/ui/broadcast.webp','Raid broadcast frame');

      const fallback = id => {
        if (id.startsWith('raid-player')) return `<svg viewBox="0 0 180 180" aria-hidden="true"><defs><radialGradient id="p"><stop stop-color="#fff4a8"/><stop offset="1" stop-color="#e9a72f"/></radialGradient></defs><path d="M43 122c-5-53 16-88 47-88s52 35 47 88c-4 34-27 51-47 51s-43-17-47-51Z" fill="url(#p)" stroke="#fff1a1" stroke-width="5"/><path d="M54 56 37 20l34 23M126 56l17-36-34 23" fill="#1d3b68"/><circle cx="72" cy="83" r="7" fill="#1d66b1"/><circle cx="108" cy="83" r="7" fill="#1d66b1"/><path d="m90 52 7 11-7 5-7-5Z" fill="#fff"/></svg>`;
        if (id.includes('common')) return `<svg viewBox="0 0 180 180" aria-hidden="true"><circle cx="90" cy="100" r="55" fill="#66d8c5" stroke="#d8fff2" stroke-width="5"/><path d="M65 47 50 20l32 18M115 47l15-27-32 18" fill="#54b967"/><circle cx="72" cy="94" r="7" fill="#1f4d66"/><circle cx="108" cy="94" r="7" fill="#1f4d66"/></svg>`;
        if (id.includes('elite')) return `<svg viewBox="0 0 180 180" aria-hidden="true"><path d="M48 148c0-68 14-104 42-104s42 36 42 104Z" fill="#50b686" stroke="#d9ffe8" stroke-width="5"/><path d="m61 53-22-28M119 53l22-28" stroke="#a87145" stroke-width="8" stroke-linecap="round"/><circle cx="76" cy="88" r="6" fill="#1f5d72"/><circle cx="104" cy="88" r="6" fill="#1f5d72"/></svg>`;
        if (id.includes('boss')) return `<svg viewBox="0 0 220 190" aria-hidden="true"><path d="M45 155c2-80 22-120 66-120s67 40 70 120Z" fill="#2a2450" stroke="#d35ab0" stroke-width="6"/><path d="m70 56-18-35 38 20m58 15 18-35-38 20" fill="#d8a63d"/><circle cx="92" cy="87" r="6" fill="#ff5ad6"/><circle cx="130" cy="87" r="6" fill="#ff5ad6"/></svg>`;
        return `<span class="raidv-css-fx" aria-hidden="true"></span>`;
      };
      const descriptor = id => rows.find(row => row[1] === id);
      const markup = (id, className='') => {
        const row = descriptor(id), url = row?.[2] || '';
        return `<span class="raidv-asset ${className}" data-raid-asset="${id}"><img class="raidv-asset-img" src="${url}" alt="" draggable="false"><span class="raidv-asset-fallback">${fallback(id)}</span></span>`;
      };
      const mountAll = root => {
        (root || document).querySelectorAll('.raidv-asset:not([data-raid-bound])').forEach(slot => {
          slot.dataset.raidBound='1'; const img=slot.querySelector('.raidv-asset-img'); if(!img)return;
          const loaded=()=>{slot.classList.add('is-loaded');slot.classList.remove('is-fallback')};
          const failed=()=>{slot.classList.add('is-fallback');slot.classList.remove('is-loaded')};
          img.addEventListener('load',loaded,{once:true}); img.addEventListener('error',failed,{once:true}); if(img.complete)(img.naturalWidth?loaded:failed)();
        });
      };
      const playerId = visual => ({down:'raid-player-main-down',revive:'raid-player-main-revive',shield:'raid-player-main-shield'}[visual?.primaryState] || ({CRITICAL:'raid-player-main-critical',NORMAL:'raid-player-main-attack',WEAK:'raid-player-main-attack','COUNTER ATTACK':'raid-player-main-hit'}[String(visual?.lastEvent||'').toUpperCase()] || 'raid-player-main-idle'));
      const enemyId = visual => {
        const t=visual?.tier||'common', primary=visual?.primaryState||'idle', event=String(visual?.lastEvent||'').toUpperCase();
        if(primary==='clear') return `raid-${t}-clear`;
        if(primary==='guard') return t==='common'?'raid-common-idle':`raid-${t}-guard`;
        if(primary==='heavy') return t==='boss'?'raid-boss-heavy-charge':`raid-${t}-attack`;
        if(event.includes('COUNTER')||event.includes('ATTACK')) return `raid-${t}-attack`;
        if(['CRITICAL','NORMAL','WEAK'].some(x=>event.includes(x))) return `raid-${t}-hit`;
        return `raid-${t}-idle`;
      };
      return Object.freeze({assets:rows.map(row=>({group:row[0],id:row[1],url:row[2],label:row[3]})),markup,mountAll,fallback,playerId,enemyId});
    })();
    window.SUMUS_RAID_ASSETS = RaidAssetDirector;
