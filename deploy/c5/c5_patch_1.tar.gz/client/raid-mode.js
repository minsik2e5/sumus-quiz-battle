    /* V0.9.3 RAID integration. RUN delegates to the frozen RaceEngine path unchanged. */
    ArenaMeta.raid = { label: 'RAID', name: 'WORD TAMING RAID', final: 'FINAL BOSS' };
    ArenaRenderer.raid = { entity: (p, i, c) => humanRunnerSvg(c, i), decor: () => '', correct: () => 'RAID HIT', wrong: 'COUNTER' };
    if (!ArenaCatalog.some(row => row[0] === 'raid')) ArenaCatalog.push(['raid', 'RAID', 'WORD TAMING RAID', '학생별 독립 PvE · 정답으로 공격을 끊으세요']);
    CharacterIcons.raid = ['🧙','🛡️','🥷','🧝','🦊','🐯','🤖','👽'];

    const V093_escape = value => String(value ?? '').replace(/[&<>"']/g, ch => ({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;' }[ch]));
    const V093_isRaid = () => state.arena === 'raid';
    const V093_events = [];
    const V093_log = (player, label) => {
      V093_events.unshift({ at: Date.now(), playerId: player.id, name: player.name, label });
      V093_events.length = Math.min(V093_events.length, 40);
    };
    const V093_publicPlayer = player => ({
      id: player.id, name: player.name, character: player.character, ready: !!player.ready,
      connected: player.connected !== false, status: player.finished ? 'FINISHED' : player.connected === false ? 'DISCONNECTED' : state.screen === 'race' ? 'ANSWERING' : player.ready ? 'READY' : 'CONNECTING',
      rangeFrom: player.rangeFrom, rangeTo: player.rangeTo, units: player.units || [],
      assignedTotal: player.assignedTotal || 0, questionIndex: player.questionIndex || 0,
      combo: player.combo || 0, correct: player.correct || 0, wrong: player.wrong || 0,
      pass: player.pass || 0, maxCombo: player.maxCombo || 0, times: player.times || [],
      finished: !!player.finished, raid: player.raid ? RaidFoundation.snapshot(player.raid) : null,
      currentQuestion: player.raid && player.questions?.[player.questionIndex] ? serializeQuestion(player.raidReviveQuestions?.[0] || player.questions[player.questionIndex]) : null,
      raidAttemptId: player.raidCurrentAttempt || ''
    });

    const V093_style = document.createElement('style');
    V093_style.textContent = `
      [data-arena="raid"]{--arena-accent:#ff5f78!important;background:radial-gradient(circle at 75% 20%,#71284466,transparent 45%),linear-gradient(145deg,#16263a,#120e22)!important}
      [data-arena="raid"] .arena-tag{color:#ffb0c0}[data-arena="raid"]:after{content:"⚔️";position:absolute;right:28px;bottom:22px;font-size:72px;filter:drop-shadow(0 12px 20px #0008)}
      body.raid-mode{--raid-red:#ff5f78;--raid-gold:#ffd166;--raid-cyan:#58e4d0}
      body.raid-mode:not(.role-student) #race>:not(.raid-teacher-root){display:none!important}
      .raid-teacher-root{height:100vh;min-height:680px;display:grid;grid-template-columns:minmax(0,1.5fr) minmax(340px,.8fr);grid-template-rows:1fr auto;background:linear-gradient(145deg,#07131e,#150f25);color:#eef7fa;overflow:hidden}
      .raid-spotlight{position:relative;display:grid;grid-template-rows:auto 1fr;padding:20px;border-right:1px solid #ffffff16;min-width:0}.raid-spot-head{display:flex;justify-content:space-between;align-items:center;gap:12px}.raid-auto{border:1px solid #58e4d055;background:#58e4d012;color:#91fff0;padding:9px 13px;border-radius:9px;font-weight:900;cursor:pointer}.raid-auto.off{color:#9aabb8;border-color:#ffffff24;background:#ffffff08}
      .raid-stage{margin-top:14px;display:grid;grid-template-columns:1fr 1.2fr;align-items:center;gap:28px;padding:clamp(18px,3vw,44px);border:1px solid #ffffff18;border-radius:24px;background:radial-gradient(circle at 72% 38%,#76244055,transparent 34%),linear-gradient(160deg,#10283a,#100d20);overflow:hidden}.raid-hero-art,.raid-enemy-art{font-size:clamp(76px,10vw,150px);text-align:center;filter:drop-shadow(0 24px 25px #000a)}.raid-enemy-art{animation:raidCharge 1.1s ease-in-out infinite alternate}.raid-duel-info{grid-column:1/-1;display:grid;grid-template-columns:1fr 1fr;gap:12px}.raid-bar{height:13px;border-radius:99px;background:#ffffff12;overflow:hidden}.raid-bar i{display:block;height:100%;background:linear-gradient(90deg,#ff5f78,#ff9d68);transition:width .25s}.raid-bar.hp i{background:linear-gradient(90deg,#41d79d,#86efac)}
      .raid-side{display:grid;grid-template-rows:minmax(0,1fr) auto;min-height:0}.raid-cards{padding:16px;display:grid;grid-template-columns:repeat(3,minmax(0,1fr));align-content:start;gap:8px;overflow:auto}.raid-card{min-width:0;padding:10px;border:1px solid #ffffff16;border-radius:12px;background:#ffffff07;color:#fff;text-align:left;cursor:pointer}.raid-card.active{border-color:#58e4d0;background:#58e4d014}.raid-card b,.raid-card small{display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.raid-card small{margin-top:4px;color:#9fb3bf;font-size:9px}.raid-card.danger{border-color:#ff5f7866}.raid-card.clear{border-color:#ffd16677}.raid-events{max-height:210px;padding:12px 16px;border-top:1px solid #ffffff16;overflow:auto}.raid-events div{padding:6px 0;border-bottom:1px solid #ffffff0b;font-size:11px}.raid-disclaimer{grid-column:1/-1;padding:8px 20px;color:#8fa4b1;font-size:10px;border-top:1px solid #ffffff10}
      .raid-student-hud{padding:9px 14px 8px;border-bottom:1px solid #ffffff15;background:linear-gradient(90deg,#151329,#231323)}.raid-student-title{display:flex;justify-content:space-between;font-size:10px;font-weight:950;letter-spacing:.1em}.raid-monster-row{display:grid;grid-template-columns:auto 1fr auto;gap:8px;align-items:center;margin-top:7px}.raid-monster-icon{font-size:31px}.raid-statline{display:flex;justify-content:space-between;margin-top:6px;color:#b4c4cc;font-size:10px}.raid-attack-track{height:7px;margin-top:7px;border-radius:99px;background:#ffffff12;overflow:hidden}.raid-attack-track i{display:block;height:100%;width:0;background:linear-gradient(90deg,#ffd166,#ff5f78);transform-origin:left;transition:width .08s linear}.raid-pattern{margin-top:5px;color:#ffd166;font-size:10px;font-weight:900;text-align:center}
      body.raid-mode.role-student .student-shell{width:min(100%,460px)}body.raid-mode.role-student .student-game-head{padding-block:6px}body.raid-mode.role-student .student-progress{display:none}body.raid-mode.role-student .student-question-wrap{padding-top:8px}body.raid-mode.role-student .student-prompt{margin:10px 0 13px}
      @keyframes raidCharge{to{transform:translateY(-6px) scale(1.025);filter:drop-shadow(0 24px 28px #ff5f7848)}}
      @media(max-width:1000px){.raid-teacher-root{grid-template-columns:1fr .85fr}.raid-cards{grid-template-columns:repeat(2,minmax(0,1fr))}}
      @media(max-width:620px){.raid-student-hud{padding-top:7px}.raid-monster-icon{font-size:27px}.raid-statline{font-size:9px}}
      @media(prefers-reduced-motion:reduce){.raid-enemy-art{animation:none}}
    `;
    document.head.appendChild(V093_style);

    const RaidTeacherView = {
      auto: true, selectedId: '', lockedUntil: 0, lastSwitchAt: 0,
      root() { let root = $('#raidTeacherRoot'); if (!root) { root = document.createElement('div'); root.id = 'raidTeacherRoot'; root.className = 'raid-teacher-root'; $('#race').append(root); } return root; },
      priority(player) { const r = player.raid || {}; if (r.cleared) return 100; if (r.battleState === 'DOWN') return 95; if (r.battleState === 'REVIVE') return 90; if (r.heavyAttackState?.active) return 85; if (r.hp <= 15) return 80; if (r.enemyHp / Math.max(1,r.enemyMaxHp) <= .1) return 75; if (r.combo >= 10) return 70; return 10 + (r.combo || 0); },
      select() { const now = Date.now(); if (!this.auto && state.players.some(p => p.id === this.selectedId)) return this.selectedId; if (now < this.lockedUntil && state.players.some(p => p.id === this.selectedId)) return this.selectedId; const next = [...state.players].sort((a,b) => this.priority(b)-this.priority(a))[0]; if (next && next.id !== this.selectedId) { this.selectedId = next.id; this.lastSwitchAt = now; this.lockedUntil = now + 3500; } return this.selectedId; },
      status(r) { if (r.cleared) return 'CLEAR'; if (r.battleState === 'DOWN') return 'DOWN'; if (r.battleState === 'REVIVE') return 'REVIVE'; if (r.heavyAttackState?.active) return 'HEAVY'; if (r.shield) return 'SHIELD'; if (r.hp <= 15) return 'DANGER'; return 'NORMAL'; },
      render() {
        if (!V093_isRaid() || AppRole !== 'teacher') return;
        document.body.classList.add('raid-mode');
        const id = this.select(), player = state.players.find(p => p.id === id) || state.players[0], r = player?.raid;
        const root = this.root();
        if (!player || !r) { root.innerHTML = '<div class="raid-spotlight"><h2>SUMUS RAID</h2><p>학생 전투를 준비 중입니다.</p></div>'; return; }
        const enemyPct = Math.max(0, r.enemyHp / Math.max(1,r.enemyMaxHp) * 100), hpPct = r.hp / r.maxHp * 100;
        const markup = `<section class="raid-spotlight"><div class="raid-spot-head"><div><small>AUTO SPOTLIGHT</small><h2>${V093_escape(player.name)} · WAVE ${r.waveIndex+1}/${r.totalWaves}</h2></div><div><button class="raid-auto ${this.auto?'':'off'}" id="raidAuto">${this.auto?'AUTO ON':'MANUAL'}</button> <button class="raid-auto off" id="raidPause">${state.race.paused?'RESUME':'PAUSE'}</button> <button class="raid-auto off" id="raidFinish">FINISH</button></div></div><div class="raid-stage"><div><div class="raid-hero-art">${r.battleState==='DOWN'?'💫':'🧙'}</div><h3>${V093_escape(player.name)}</h3></div><div><div class="raid-enemy-art">${r.cleared?'✨':'👹'}</div><h3>${r.enemyType}</h3></div><div class="raid-duel-info"><div><b>PLAYER HP ${r.hp}/${r.maxHp}</b><div class="raid-bar hp"><i style="width:${hpPct}%"></i></div><small>COMBO ×${r.combo} · SHIELD ${r.shield}</small></div><div><b>${r.lastEvent}</b><div class="raid-bar"><i style="width:${enemyPct}%"></i></div><small>MONSTER ${Math.max(0,r.enemyHp)}/${r.enemyMaxHp} · DAMAGE ${r.totalDamage}</small></div></div></div></section><aside class="raid-side"><div class="raid-cards">${state.players.map(p=>{const x=p.raid||{},status=this.status(x);return`<button class="raid-card ${p.id===id?'active':''} ${status.toLowerCase()}" data-raid-player="${p.id}"><b>${V093_escape(p.name)}</b><small>HP ${x.hp??'-'} · W${(x.waveIndex??0)+1}/${x.totalWaves??'-'}</small><small>${status} · ×${x.combo||0}</small></button>`}).join('')}</div><div class="raid-events"><b>KEY EVENTS</b>${V093_events.slice(0,14).map(e=>`<div>${V093_escape(e.name)} · ${V093_escape(e.label)}</div>`).join('')}</div></aside><div class="raid-disclaimer">진행률 · CLEAR · 정답률 · 최고 COMBO · DAMAGE를 함께 표시합니다. DAMAGE는 서로 다른 문제 유형 간 학업 성취도 순위가 아닙니다.</div>`;
        if (this.lastMarkup === markup && root.childElementCount) return;
        this.lastMarkup = markup;
        root.innerHTML = markup;
        $('#raidAuto')?.addEventListener('click', () => { this.auto = !this.auto; this.render(); });
        $('#raidPause')?.addEventListener('click', () => { $('#pauseRace')?.click(); setTimeout(() => this.render(), 0); });
        $('#raidFinish')?.addEventListener('click', () => $('#finishRace')?.click());
        $$('[data-raid-player]', root).forEach(button => button.addEventListener('click', () => { this.auto = false; this.selectedId = button.dataset.raidPlayer; this.render(); }));
      }
    };

    const V093_baseSnapshot = battleSnapshot;
    battleSnapshot = function(targetClientId = '') {
      const snapshot = V093_baseSnapshot(targetClientId), payload = snapshot?.payload || snapshot;
      if (V093_isRaid() && payload) payload.players = state.players.map(V093_publicPlayer);
      return snapshot;
    };

    const V093_baseSetup = RaceEngine.setup.bind(RaceEngine);
    RaceEngine.setup = function() {
      if (!V093_isRaid()) return V093_baseSetup();
      const count = state.players.length;
      state.players.forEach((player, index) => {
        const questions = QuizEngine.buildQuestions(player);
        Object.assign(player, { answered:0, correct:0, wrong:0, pass:0, combo:0, maxCombo:0, times:[], assignedTotal:questions.length, questions, questionIndex:0, finished:false, finishRank:0, initialRank:index+1, raidCorrectQuestions:[], raidReviveQuestions:[] });
        player.raid = RaidFoundation.create(questions.length);
      });
      state.race.order = state.players.map(p=>p.id); state.race.running = true; state.race.paused = false;
      RaidTeacherView.render();
      setTimeout(() => TeacherBridge.assignAll(), 0);
      TeacherBridge.publish();
      return count;
    };

    const V093_assign = (player, question, options = {}) => {
      if (!player || !question || player.finished) return;
      const now = Date.now(), waitForAudio = question.type === 'listen' && !options.listenReady;
      if (!options.continueCurrent) RaidFoundation.beginQuestion(player.raid, question, now, { waitForAudio });
      const attemptId = `raid-${player.questionIndex}-${now.toString(36)}-${Math.random().toString(36).slice(2,5)}`;
      player.raidCurrentAttempt = attemptId;
      const remainingMs = player.raid.attackDeadline ? Math.max(0, player.raid.attackDeadline - now) : 0;
      LocalTransport.send('QUESTION_ASSIGN', { ...EventPayload.base(player.id,{questionId:question.id,attemptId}), targetClientId:options.targetClientId||'', question:serializeQuestion(question), player:V093_publicPlayer(player), rank:teacherRank(player.id), timeLimit:options.continueCurrent?remainingMs/1000:waitForAudio?0:player.raid.attackDurationMs/1000, raidTiming:{questionStartAt:player.raid.attackStartAt,attackDeadline:player.raid.attackDeadline,durationMs:player.raid.attackDurationMs}, arena:'raid' });
      if (!options.continueCurrent) TeacherBridge.publish();
    };
    const V093_currentQuestion = player => player.raidReviveQuestions?.[0] || player.questions?.[player.questionIndex];
    const V093_prepareRevive = player => {
      if (player.raid.battleState !== 'DOWN' || player.raidReviveQuestions.length) return;
      const easy = player.raidCorrectQuestions.slice(-4).reverse();
      const fallback = player.questions[player.questionIndex] || player.questions[0];
      player.raidReviveQuestions = [easy[0] || fallback, easy[1] || easy[0] || fallback].filter(Boolean);
      player.raid.battleState = 'REVIVE'; player.raid.lastEvent = 'REVIVE CHALLENGE 0/2';
      V093_log(player, 'DOWN');
    };
    const V093_finishIfNeeded = player => {
      if (player.raid.cleared) player.raid.earlyClear = player.questionIndex < player.assignedTotal - 1;
      if (player.questionIndex >= player.questions.length || player.raid.cleared) {
        player.finished = true; player.finishRank = state.players.filter(p=>p.finished).length; player.finishAt = Date.now();
        V093_log(player, player.raid.cleared ? 'BOSS CLEAR · WORD TAMED' : 'QUESTIONS COMPLETE');
        LocalTransport.send('PLAYER_FINISHED',{...EventPayload.base(player.id),player:V093_publicPlayer(player),rank:player.finishRank});
      }
    };

    const V093_baseTeacherAnswer = TeacherBridge.answer.bind(TeacherBridge);
    TeacherBridge.answer = function(payload) {
      if (!V093_isRaid()) return V093_baseTeacherAnswer(payload);
      const key = `${payload.playerId}|${payload.questionId}|${payload.attemptId}`;
      if (this.resolved.has(key)) return;
      this.resolved.add(key);
      const player = state.players.find(p=>p.id===payload.playerId), q = V093_currentQuestion(player);
      if (!player || !q || q.id !== payload.questionId || player.finished || state.race.paused) return;
      const now = Date.now(), raid = player.raid;
      if (raid.attackDeadline && now >= raid.attackDeadline) RaidFoundation.applyTimeout(raid, raid.attackDeadline);
      if (payload.action === 'timeout') {
        RaidFoundation.applyTimeout(raid, now); player.wrong += 1; player.combo = raid.combo;
        if (raid.battleState === 'DOWN') V093_prepareRevive(player);
        LocalTransport.send('ANSWER_RESULT',{...EventPayload.base(player.id,{questionId:q.id,attemptId:payload.attemptId}),result:'wrong',reason:'timeout',combo:raid.combo,rank:teacherRank(player.id),player:V093_publicPlayer(player)});
        V093_log(player, raid.lastEvent); RaidTeacherView.render();
        return setTimeout(()=>V093_assign(player,V093_currentQuestion(player),{continueCurrent:true}),420);
      }
      const correctAnswer = QuizEngine.judge(q,payload.answer);
      let result, advance = false, detail;
      if (payload.action === 'pass') { result='pass'; detail=RaidFoundation.pass(raid,q.id,now); player.pass += 1; advance=true; q.passCount=(q.passCount||0)+1; if(state.config.passRetry&&q.passCount<=state.config.passMaxRetry)player.questions.push(q); }
      else if (correctAnswer) { result='correct'; detail=RaidFoundation.correct(raid,q.type,now); player.correct += 1; player.raidCorrectQuestions.push(q); advance=true; }
      else { result='wrong'; detail=RaidFoundation.wrong(raid,q.id,now); player.wrong += 1; advance=detail.advance; if(advance&&state.config.passRetry)player.questions.push(q); }
      player.answered += advance?1:0; player.combo=raid.combo; player.maxCombo=raid.maxCombo; player.times.push(Math.max(.1,(now-(raid.attackStartAt||now))/1000));
      if (raid.battleState === 'DOWN') V093_prepareRevive(player);
      if (player.raidReviveQuestions.length && correctAnswer) { player.raidReviveQuestions.shift(); advance=false; if(raid.battleState==='ACTIVE')player.raidReviveQuestions=[]; }
      if (advance) player.questionIndex += 1;
      if (correctAnswer && raid.waveIndex === raid.totalWaves - 1 && !raid.heavyTriggered && player.correct >= 4 && !raid.guardState?.active) {
        RaidFoundation.activateHeavy(raid); raid.heavyTriggered = true; V093_log(player,'HEAVY ATTACK');
      }
      if (detail?.comboEvents?.length) detail.comboEvents.forEach(label=>V093_log(player,label));
      if (['critical','normal','weak'].includes(detail?.grade)) V093_log(player,detail.grade.toUpperCase());
      if (raid.lastEvent.includes('HEAVY')||raid.lastEvent.includes('BREAK')||raid.lastEvent==='REVIVE') V093_log(player,raid.lastEvent);
      V093_finishIfNeeded(player);
      LocalTransport.send('ANSWER_RESULT',{...EventPayload.base(player.id,{questionId:q.id,attemptId:payload.attemptId}),result,reason:result,correctAnswer:state.config.showAnswer&&result==='wrong'?q.answer:'',bonus:detail?.damage||0,combo:raid.combo,rank:teacherRank(player.id),player:V093_publicPlayer(player),raidDetail:detail});
      Events.emit('PLAYER_PROGRESS',{playerId:player.id,result,responseTime:player.times.at(-1),raid:true});
      RaidTeacherView.render(); this.publish();
      setTimeout(V091_saveTeacherState,0);
      if (!player.finished) setTimeout(()=>V093_assign(player,V093_currentQuestion(player),{continueCurrent:!advance}),420);
      else if (state.players.every(p=>p.finished)) setTimeout(()=>RaceEngine.finish(),850);
    };
    const V093_baseAssign = TeacherBridge.assign.bind(TeacherBridge);
    TeacherBridge.assign = function(player,q,options={}){ return V093_isRaid()?V093_assign(player,q,{continueCurrent:!!options.reuse,targetClientId:options.targetClientId||''}):V093_baseAssign(player,q,options); };

    const V093_baseTeacherHandle = TeacherBridge.handle;
    TeacherBridge.handle = function(message) {
      if (V093_isRaid() && message?.type === 'RAID_LISTEN_READY') {
        const p=message.payload||{}, player=state.players.find(x=>x.id===p.playerId), q=V093_currentQuestion(player);
        if(player&&q?.id===p.questionId&&!player.raid.attackStartAt){RaidFoundation.startListenTimer(player.raid,Date.now());LocalTransport.send('RAID_TIMING',{...EventPayload.base(player.id,{questionId:q.id}),targetClientId:message.senderId,raidTiming:{questionStartAt:player.raid.attackStartAt,attackDeadline:player.raid.attackDeadline,durationMs:player.raid.attackDurationMs}});this.publish();}
        return;
      }
      return V093_baseTeacherHandle.call(this,message);
    };

    Events.on('GAME_PAUSE',()=>{if(V093_isRaid())state.raidPausedAt=Date.now()});
    Events.on('GAME_RESUME',()=>{if(!V093_isRaid()||!state.raidPausedAt)return;const shift=Date.now()-state.raidPausedAt;state.players.forEach(p=>{if(p.raid?.attackDeadline){p.raid.attackStartAt+=shift;p.raid.attackDeadline+=shift}});state.raidPausedAt=0;TeacherBridge.publish()});
    setInterval(()=>{
      if(AppRole!=='teacher'||!V093_isRaid()||!state.race.running||state.race.paused)return;
      const now=Date.now();state.players.forEach(player=>{const r=player.raid,q=V093_currentQuestion(player);if(!player.finished&&q&&r?.attackDeadline&&!r.timeoutHitApplied&&now>=r.attackDeadline&&player.raidCurrentAttempt)TeacherBridge.answer({...EventPayload.base(player.id,{questionId:q.id,attemptId:player.raidCurrentAttempt}),action:'timeout',answer:'',responseTime:r.attackDurationMs/1000})});
    },250);

    const V093_baseRenderArenaScene=RaceEngine.renderArenaScene.bind(RaceEngine),V093_baseRenderRunners=RaceEngine.renderRunners.bind(RaceEngine),V093_baseFrame=RaceEngine.frame.bind(RaceEngine);
    RaceEngine.renderArenaScene=function(){return V093_isRaid()?RaidTeacherView.render():V093_baseRenderArenaScene()};
    RaceEngine.renderRunners=function(){return V093_isRaid()?RaidTeacherView.render():V093_baseRenderRunners()};
    RaceEngine.frame=function(){return V093_isRaid()?undefined:V093_baseFrame()};

    const V093_baseStudentAccept = StudentApp.acceptSnapshot;
    StudentApp.acceptSnapshot = function(snap){
      const result=V093_baseStudentAccept.call(this,snap);
      if(snap?.arena==='raid'){
        document.body.classList.add('raid-mode');const p=snap.players?.find(x=>x.id===StudentSession.playerId);
        if(p?.raid){
          StudentSession.player=p;
          if(snap.running&&!p.finished&&p.currentQuestion&&p.raidAttemptId&&StudentSession.question?.id!==p.currentQuestion.id){
            const remaining=Math.max(0,(p.raid.attackDeadline||0)-Date.now());
            this.showQuestion({question:p.currentQuestion,attemptId:p.raidAttemptId,player:p,rank:1,timeLimit:remaining/1000,raidTiming:{questionStartAt:p.raid.attackStartAt,attackDeadline:p.raid.attackDeadline,durationMs:p.raid.attackDurationMs},arena:'raid'});
          }
        }
      }
      return result
    };
    const V093_baseStudentHandle = StudentApp.handle;
    StudentApp.handle = function(message){
      if(message?.type==='RAID_TIMING'&&message.payload?.playerId===StudentSession.playerId){const t=message.payload.raidTiming;StudentSession.raidTiming=t;StudentSession.timeLimit=t.durationMs/1000;LocalClock.start({seconds:StudentSession.timeLimit,onTick:(ratio,left)=>this.tick(ratio,left),onExpire:()=>this.submit('','timeout')});this.renderRaidHud();return;}
      const result=V093_baseStudentHandle.call(this,message);
      if(message?.type==='TRANSPORT_STATUS'&&message.payload?.status==='live'&&StudentSession.snapshot?.arena==='raid'&&StudentSession.playerId){
        setTimeout(()=>LocalTransport.send('TRANSPORT_PING',{...EventPayload.base(StudentSession.playerId),reconnectToken:StudentSession.reconnectToken,requestQuestion:true}),40);
      }
      return result;
    };
    const V093_baseShowQuestion = StudentApp.showQuestion;
    StudentApp.showQuestion = function(payload){if(payload.arena==='raid'||payload.player?.raid){StudentSession.raidTiming=payload.raidTiming;document.body.classList.add('raid-mode');}return V093_baseShowQuestion.call(this,payload)};
    const V093_baseStudentRender = StudentApp.render;
    StudentApp.render = function(){const result=V093_baseStudentRender.call(this);this.renderRaidHud();return result};
    StudentApp.renderRaidHud = function(){
      const raid=StudentSession.player?.raid, isRaid=StudentSession.snapshot?.arena==='raid'||!!raid;if(!isRaid||!raid)return;
      document.body.classList.add('raid-mode');let hud=$('#raidStudentHud');if(!hud){hud=document.createElement('section');hud.id='raidStudentHud';hud.className='raid-student-hud';const anchor=$('.student-game-head')||$('.student-view');anchor?.parentNode?.insertBefore(hud,anchor);}
      const enemyPct=Math.max(0,raid.enemyHp/Math.max(1,raid.enemyMaxHp)*100), hpPct=raid.hp/raid.maxHp*100, heavy=raid.heavyAttackState?.active?`HEAVY ATTACK ${raid.heavyAttackState.progress}/2`:raid.guardState?.active?'GUARD · BREAK WITH NEXT ANSWER':'';
      hud.innerHTML=`<div class="raid-student-title"><span>SUMUS RAID · WAVE ${raid.waveIndex+1}/${raid.totalWaves}</span><span>${raid.enemyType}</span></div><div class="raid-monster-row"><span class="raid-monster-icon">👹</span><div><div class="raid-bar"><i style="width:${enemyPct}%"></i></div><small>${Math.max(0,raid.enemyHp)} / ${raid.enemyMaxHp}</small></div><b>${raid.lastEvent}</b></div><div class="raid-statline"><span>HP ${raid.hp}/${raid.maxHp} (${Math.round(hpPct)}%)</span><span>COMBO ×${raid.combo}</span><span>SHIELD ${raid.shield}</span></div><div class="raid-attack-track"><i id="raidAttackFill"></i></div>${heavy?`<div class="raid-pattern">${heavy}</div>`:''}`;
      this.updateRaidGauge();
    };
    StudentApp.updateRaidGauge = function(){cancelAnimationFrame(this.raidGaugeRaf);const frame=()=>{const fill=$('#raidAttackFill'),t=StudentSession.raidTiming;if(!fill||!t)return;const duration=t.durationMs||1,ratio=t.attackDeadline?Math.min(1,Math.max(0,(Date.now()-t.questionStartAt)/duration)):0;fill.style.width=`${ratio*100}%`;if(ratio<1)this.raidGaugeRaf=requestAnimationFrame(frame)};this.raidGaugeRaf=requestAnimationFrame(frame)};
    const V093_audioPlay = AudioPronunciationProvider.play.bind(AudioPronunciationProvider);
    AudioPronunciationProvider.play = function(text,onState=()=>{}){const raidListen=StudentSession.snapshot?.arena==='raid'&&StudentSession.question?.type==='listen';return V093_audioPlay(text,playing=>{onState(playing);if(raidListen&&!playing)LocalTransport.send('RAID_LISTEN_READY',{...EventPayload.base(StudentSession.playerId,{questionId:StudentSession.question.id,attemptId:StudentSession.attemptId})})})};

    const V093_baseRenderLobby = renderLobby;
    renderLobby = function(){const result=V093_baseRenderLobby();if(V093_isRaid())RaidTeacherView.render();return result};
    const V093_baseRenderResults = renderResults;
    renderResults = function(){if(!V093_isRaid())return V093_baseRenderResults();const sorted=[...state.players].sort((a,b)=>(b.raid?.cleared?1:0)-(a.raid?.cleared?1:0)||(b.correct/Math.max(1,b.answered))-(a.correct/Math.max(1,a.answered))||(b.raid?.maxCombo||0)-(a.raid?.maxCombo||0));$('#resultsBody').innerHTML=sorted.map((p,i)=>`<tr><td>${i+1}</td><td><b>${V093_escape(p.name)}</b></td><td>${p.correct}</td><td>${p.wrong}</td><td>${p.pass}</td><td>${Math.round(p.correct/Math.max(1,p.answered)*100)}%</td><td>${avg(p.times).toFixed(1)}s</td><td>${p.times.length?`${Math.min(...p.times).toFixed(1)}s`:'-'}</td><td>×${p.raid?.maxCombo||0}</td><td>${p.raid?.cleared?'CLEAR':`W${(p.raid?.waveIndex||0)+1}`} · DMG ${p.raid?.totalDamage||0}</td></tr>`).join('');$('#awards').innerHTML='<div class="award"><span>RAID RESULT</span><b>CLEAR · ACCURACY · COMBO · DAMAGE</b></div>';$('#podium').innerHTML='';updateArenaLabels()};
    window.SUMUS_RAID = { foundation:RaidFoundation, teacherView:RaidTeacherView, snapshot:()=>state.players.map(V093_publicPlayer), events:V093_events };
